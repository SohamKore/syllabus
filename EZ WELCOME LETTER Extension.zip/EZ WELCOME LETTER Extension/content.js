// github.com/SohamKore
(function () {

  const SYLLABUS_BASE = "https://sohamkore.github.io/syllabus/";

  // 👉 UPDATED welcome + rules PDF
  const WELCOME_PDF =
    "https://sohamkore.github.io/syllabus/WELCOME%20LETTER%20(UPDATED).pdf";

  const COURSE_TO_PDF = {

    "MS EXCEL": "EXCEL.pdf",
    "MS WORD": "MS OFFICE 2021.pdf",
    "MS POWERPOINT": "MS OFFICE 2021.pdf",
    "MS POWER POINT": "MS OFFICE 2021.pdf",
    "ADVANCE EXCEL": "ADV EXCEL.pdf",
    "ADV EXCEL": "ADV EXCEL.pdf",
    "GST": "GST.pdf",
    "DATA STRUCTURES": "DS.pdf",
    "ADVANCED JAVA": "Adv. Java.pdf",
    "ADVANCED SQL": "SQL Advanced.pdf",
    "ADVANCED DATA STRUCTURES": "DS Advanced.pdf",

    "PYTHON": "PYTHON.pdf",
    "PYTHON ADV": "PYTHON ADV.pdf",
    "PYTHON EXPERT": "PYTHON EXPERT.pdf",

    "C PROGRAMMING": "C PROGRAMMING.pdf",
    "C": "C PROGRAMMING.pdf",
    "C++": "C++.pdf",

    "CORE JAVA": "Core Java.pdf",
    "ADV JAVA": "Adv. Java.pdf",
    "ADV. JAVA": "Adv. Java.pdf",

    "HTML": "HTML.pdf",
    "CSS": "CSS.pdf",
    "JAVASCRIPT": "Javascript (FS).pdf",
    "JAVA SCRIPT": "Javascript (FS).pdf",

    "AUTOCAD": "AUTOCAD.pdf",
    "CATIA": "CATIA.pdf",
    "SQL": "sql.pdf",
    "MYSQL": "sql.pdf",
    "MY SQL": "sql.pdf",
    
    "TALLY": "Tally.pdf",
    "TALLY ERP9": "TALLY ERP9.pdf",
    "TALLY PRIME": "TALLY PRIME.pdf",

    "POWER BI": "POWERBI.pdf",
    "GRAPHIC DESIGN": "GRAPHIC DESIGN.pdf",
    "DIGITAL MARKETING": "Digital Marketing.pdf"
  };

  // ---------------- UI ----------------

  const panel = document.createElement("div");
  panel.style.position = "fixed";
  panel.style.right = "15px";
// github.com/SohamKore
  panel.style.bottom = "15px";
  panel.style.width = "360px";
  panel.style.background = "#fff";
  panel.style.border = "1px solid #ccc";
  panel.style.borderRadius = "8px";
  panel.style.boxShadow = "0 4px 10px rgba(0,0,0,.15)";
  panel.style.padding = "10px";
  panel.style.zIndex = 999999;
  panel.style.fontFamily = "Arial, sans-serif";
  panel.style.fontSize = "13px";

  panel.innerHTML = `
    <div style="font-weight:bold;margin-bottom:8px;">📄 EZ WELCOME LETTER</div>
    <div id="aph-list" style="margin-bottom:10px">Detecting courses…</div>

    <button id="aph-print-form" style="width:100%;margin-bottom:6px">
      Print Admission Form
    </button>

    <button id="aph-welcome" style="width:100%">
      Open Welcome & Rules
    </button>
  `;

  document.body.appendChild(panel);

  // Hide helper panel while printing
const originalDisplay = panel.style.display;

window.addEventListener("beforeprint", () => {
  panel.style.display = "none";
});

window.addEventListener("afterprint", () => {
  panel.style.display = originalDisplay || "block";
});

  const listDiv   = panel.querySelector("#aph-list");
  const welcomeBtn = panel.querySelector("#aph-welcome");
  const printFormBtn = panel.querySelector("#aph-print-form");

  // ---------------- helpers ----------------

  function cleanCourseText(text) {
    return text
      .replace(/\([^)]*\)/g, "")
      .replace(/\s+/g, " ")
      .trim();
  }

  function normalizeKey(text) {
    return cleanCourseText(text).toUpperCase();
  }
// github.com/SohamKore

  // ---------------- read courses ----------------

  function getCoursesFromPage() {

    const label = [...document.querySelectorAll("label")]
      .find(l => l.textContent.toLowerCase().includes("course content"));

    if (!label) return [];

    let txt = label.textContent.replace(/course content\s*:/i, "");

    return txt
      .split(",")
      .map(c => cleanCourseText(c))
      .filter(c => c.length > 0);
  }

  const studentCourses = getCoursesFromPage();

  // ---------------- build UI rows ----------------

  if (studentCourses.length === 0) {

    listDiv.innerHTML = "❌ Course Content field not found.";

  } else {

    listDiv.innerHTML = "";

    studentCourses.forEach(course => {

      const key = normalizeKey(course);
      const pdfName = COURSE_TO_PDF[key];

      const row = document.createElement("div");
      row.style.display = "flex";
      row.style.alignItems = "center";
      row.style.marginBottom = "6px";

      const label = document.createElement("div");
      label.style.flex = "1";
      label.textContent = course;

      const btn = document.createElement("button");
      btn.style.marginLeft = "6px";

      if (!pdfName) {

        btn.textContent = "Not mapped";
        // btn.disabled = true;
          btn.onclick = () => {
    window.open("https://sohamkore.github.io/syllabus", "_blank");
  };

      } else {

        btn.textContent = "Print";

        btn.onclick = () => {

          const url =
            SYLLABUS_BASE +
            encodeURIComponent(pdfName).replace(/%2F/g, "/");

          window.open(url, "_blank");
        };
      }

      row.appendChild(label);
      row.appendChild(btn);

      listDiv.appendChild(row);
    });
  }

  // ---------------- buttons ----------------

  // 👉 Print the admission form page which is already open
  printFormBtn.onclick = () => {
    window.print();
  };

  // 👉 Open updated welcome + rules PDF
  welcomeBtn.onclick = () => {
// github.com/SohamKore
    window.open(WELCOME_PDF, "_blank");
  };

})();
// github.com/SohamKore
